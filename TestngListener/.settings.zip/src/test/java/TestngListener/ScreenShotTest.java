package TestngListener;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

@Listeners(CustomListener.class)	
public class ScreenShotTest extends BaseClass { //ScreenShotTest.java is a child extends BaseClass
	
	@BeforeMethod
	public void setup() {
		/*calling initialization() method directly from base class
			so that can be inherit property without creating the object*/
		
		initialization(); 
		// In this we call driver.quit method  to close the method
		driver.quit();
	}
	
	@AfterMethod
	public void tearDown() {
		
		
	}
	
	@Test
public void takeScreenshotTest() {
		Assert.assertEquals(false, true);
		}

}
