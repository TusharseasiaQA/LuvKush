package TestngListener;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.ITestResult;

public class BaseClass {
	//Creating a variable
	public static WebDriver driver;
	
	//Now creating a initialization mehtod 
	public static void initialization() {
		// in this initialization mehtod i will launch my google chrome
		System.setProperty("webdriver.chrome.driver", "E:\\Selenium Drivers\\chromedriver.exe" );
		driver=new ChromeDriver();
		driver.get("https://www.google.com/");
	}
	
	//we will create the failed method and we will write the logic to take screenShot
	public void failed() {
		//Now we have to typecaste
		//This particular think have method getScreenshotAs() method name and output.file you have to pass
		//Then it will written a file object and so we will store in a file object
		
		//Now we have to take the screenshot
		//now for taking the screenshot we have one class i.e., file Utils
		//destination file i want to store inside a file object and giving the folder location where we want to store the screenshot
		try {
			TakesScreenshot src = (TakesScreenshot) driver;
			File sc = src.getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(sc, new File("./Screenshots/capture.png")); /*parameterizing the capture screenshot method, it prevent overriding*/
			System.out.println("Screenshot taken");
		} catch (Exception e) {
			System.out.println("Exception While taking the Screenshot"+e.getMessage());
		} 
		 //surrounded with try catch block when file is not found at that time we can have 
	}

	

}
