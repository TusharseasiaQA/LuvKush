package TestngListener;

import org.testng.ITestListener;
import org.testng.ITestResult;

/*The custom listener extending base class and it is implementing testng listener 
which is already available call iTestListener*/
public class CustomListener extends BaseClass implements ITestListener {
	
	
	public void onTestStart(ITestResult result) {
		
	}
	
	
	public void onTestSuccess(ITestResult result) {
		
	}
	
	
	public void onTestFailure(ITestResult result) {
		System.out.println("FAILED Test");
		//calling failed method frome base class
		failed();
	}
	
	
	public void onTestSkipped(ITestResult result) {
		
	}

}



